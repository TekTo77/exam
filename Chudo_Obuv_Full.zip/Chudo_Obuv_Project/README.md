# Чудо Обувь — полный проект

Полная простая инструкция — **INSTRUCTION.md** в этой папке.

- `python main.py` — полное приложение.
- `python import_db.py` — отдельный импорт Excel.
- `python Excel_Editor/main.py` — отдельный редактор.
- Подключение — `postgres_connection.json` в корне.
- Дизайн — `design.py` в корне.

Обычный PostgreSQL и Docker поддерживаются. Перед запуском установи
зависимости из `requirements.txt`, запусти сервер и проверь подключение.
В приложенном Docker-примере данные временные.
